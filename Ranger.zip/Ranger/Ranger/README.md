BOT INTEIRAMENTE EDITÁVEL FEITO POR TRASHDK E CAUSS


CANAIS -



TRASHDK - https://youtube.com/channel/UCOqlFzRrB8IZUWUx1cwCeUw


CAUSS - https://youtube.com/c/caussZ
